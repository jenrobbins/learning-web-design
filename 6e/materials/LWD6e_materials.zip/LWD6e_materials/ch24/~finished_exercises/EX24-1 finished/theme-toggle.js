let $toggle = document.createElement("button");
$toggle.innerText = "Theme Toggle";
document.body.appendChild( $toggle );