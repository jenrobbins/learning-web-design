let $toggle = document.createElement("button");
$toggle.type = "button";
$toggle.classList.add( "theme-toggle" );
$toggle.innerText = "Theme Toggle";
document.body.appendChild( $toggle );